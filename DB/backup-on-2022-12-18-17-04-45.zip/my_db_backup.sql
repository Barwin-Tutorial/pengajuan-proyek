#
# TABLE STRUCTURE FOR: aplikasi
#

DROP TABLE IF EXISTS `aplikasi`;

CREATE TABLE `aplikasi` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `nama_owner` varchar(100) DEFAULT NULL,
  `alamat` text,
  `tlp` varchar(50) DEFAULT NULL,
  `brand` varchar(10) DEFAULT NULL,
  `title` varchar(20) DEFAULT NULL,
  `nama_aplikasi` varchar(100) DEFAULT NULL,
  `logo` varchar(100) DEFAULT NULL,
  `copy_right` varchar(50) DEFAULT NULL,
  `versi` varchar(20) DEFAULT NULL,
  `tahun` year DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `nama_pengirim` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `aplikasi` (`id`, `nama_owner`, `alamat`, `tlp`, `brand`, `title`, `nama_aplikasi`, `logo`, `copy_right`, `versi`, `tahun`, `email`, `nama_pengirim`, `password`) VALUES (1, 'PT. ARYO CODING', 'jalan raya', '085838333009', NULL, 'Inventory', 'Inventory', 'Logo.png', 'Copy Right ©', '1.0.0.0', '2022', 'aryoblack88@gmail.com', 'Aryo Coding', 'pfpinffqxutdjexq');


#
# TABLE STRUCTURE FOR: barang
#

DROP TABLE IF EXISTS `barang`;

CREATE TABLE `barang` (
  `id` int NOT NULL AUTO_INCREMENT,
  `barcode` varchar(15) DEFAULT NULL,
  `kdbarang` varchar(15) DEFAULT NULL,
  `nama` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `harga` decimal(10,0) DEFAULT NULL,
  `kemasan` int DEFAULT NULL,
  `perundangan` int DEFAULT NULL,
  `berat` varchar(12) DEFAULT NULL,
  `rak` varchar(30) DEFAULT NULL,
  `aktivasi` enum('Ya','Tidak') DEFAULT 'Ya',
  `user_input` int DEFAULT NULL,
  `id_gudang` int DEFAULT NULL,
  `stok` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `nama_barang` (`nama`),
  KEY `id_gudang` (`id_gudang`),
  KEY `perundangan` (`perundangan`),
  KEY `kemasan` (`kemasan`),
  CONSTRAINT `barang_ibfk_1` FOREIGN KEY (`id_gudang`) REFERENCES `gudang` (`id`),
  CONSTRAINT `barang_ibfk_2` FOREIGN KEY (`perundangan`) REFERENCES `perundangan` (`id`),
  CONSTRAINT `barang_ibfk_3` FOREIGN KEY (`kemasan`) REFERENCES `satuan` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `barang` (`id`, `barcode`, `kdbarang`, `nama`, `harga`, `kemasan`, `perundangan`, `berat`, `rak`, `aktivasi`, `user_input`, `id_gudang`, `stok`) VALUES (4, '123456', '123456', 'Barang 1', '200000', 1, 1, '1gr', '3', 'Ya', 1, 1, '0');
INSERT INTO `barang` (`id`, `barcode`, `kdbarang`, `nama`, `harga`, `kemasan`, `perundangan`, `berat`, `rak`, `aktivasi`, `user_input`, `id_gudang`, `stok`) VALUES (5, 'B12323', 'B123', 'Barang 2', '34000', 1, 1, '1gr', 'r2', 'Ya', 1, 1, '0');
INSERT INTO `barang` (`id`, `barcode`, `kdbarang`, `nama`, `harga`, `kemasan`, `perundangan`, `berat`, `rak`, `aktivasi`, `user_input`, `id_gudang`, `stok`) VALUES (6, '6543', '6543', 'barang 3', '23000', 1, 4, 'gr1', 'r3', 'Ya', 1, 1, '0');


#
# TABLE STRUCTURE FOR: gudang
#

DROP TABLE IF EXISTS `gudang`;

CREATE TABLE `gudang` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) DEFAULT NULL,
  `notelp` varchar(50) DEFAULT NULL,
  `alamat` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `gudang` (`id`, `nama`, `notelp`, `alamat`) VALUES (1, 'Gudang A', '1245678', 'jalansndasa');
INSERT INTO `gudang` (`id`, `nama`, `notelp`, `alamat`) VALUES (2, 'Gudang B', '21231231', 'asdasdasdasda');


#
# TABLE STRUCTURE FOR: keluar
#

DROP TABLE IF EXISTS `keluar`;

CREATE TABLE `keluar` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_pelanggan` int DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `user_input` int DEFAULT NULL,
  `id_gudang` int DEFAULT NULL,
  `tgl_input` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `faktur` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_pelanggan` (`id_pelanggan`),
  KEY `user_input` (`user_input`),
  KEY `id_gudang` (`id_gudang`),
  CONSTRAINT `keluar_ibfk_1` FOREIGN KEY (`id_pelanggan`) REFERENCES `pelanggan` (`id`),
  CONSTRAINT `keluar_ibfk_3` FOREIGN KEY (`id_gudang`) REFERENCES `gudang` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `keluar` (`id`, `id_pelanggan`, `tanggal`, `user_input`, `id_gudang`, `tgl_input`, `faktur`) VALUES (1, 1, '2022-12-18', 1, 1, '2022-12-18 16:40:38', 'KB-00001-1/18-12-2022');
INSERT INTO `keluar` (`id`, `id_pelanggan`, `tanggal`, `user_input`, `id_gudang`, `tgl_input`, `faktur`) VALUES (2, 1, '2022-12-18', 1, 1, '2022-12-18 16:50:14', 'KB-00002-1/18-12-2022');


#
# TABLE STRUCTURE FOR: keluar_detail
#

DROP TABLE IF EXISTS `keluar_detail`;

CREATE TABLE `keluar_detail` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_keluar` int DEFAULT NULL,
  `id_barang` int DEFAULT NULL,
  `jumlah` double DEFAULT '0',
  `sisa` double NOT NULL DEFAULT '0',
  `harga_jual` double NOT NULL DEFAULT '0',
  `kemasan` int DEFAULT NULL,
  `ed` date DEFAULT NULL,
  `nobatch` varchar(50) DEFAULT NULL,
  `id_user` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_keluar_fk` (`id_keluar`),
  KEY `id_barang` (`id_barang`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `keluar_detail` (`id`, `id_keluar`, `id_barang`, `jumlah`, `sisa`, `harga_jual`, `kemasan`, `ed`, `nobatch`, `id_user`) VALUES (2, 1, 4, '2', '0', '200000', 1, '2023-02-28', '23456', 1);
INSERT INTO `keluar_detail` (`id`, `id_keluar`, `id_barang`, `jumlah`, `sisa`, `harga_jual`, `kemasan`, `ed`, `nobatch`, `id_user`) VALUES (7, 2, 4, '5', '0', '200000', 1, '2023-02-28', '32342342', 1);


#
# TABLE STRUCTURE FOR: pelanggan
#

DROP TABLE IF EXISTS `pelanggan`;

CREATE TABLE `pelanggan` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) DEFAULT NULL,
  `alamat` text,
  `kp_instalasi` varchar(100) DEFAULT NULL,
  `admin_farmasi` varchar(100) DEFAULT NULL,
  `notelp` varchar(50) DEFAULT NULL,
  `user_input` int DEFAULT NULL,
  `id_gudang` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_gudang` (`id_gudang`),
  CONSTRAINT `pelanggan_ibfk_1` FOREIGN KEY (`id_gudang`) REFERENCES `gudang` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `pelanggan` (`id`, `nama`, `alamat`, `kp_instalasi`, `admin_farmasi`, `notelp`, `user_input`, `id_gudang`) VALUES (1, 'test pel', 'jalans sjsjdnasda', 'aryo', 'admin', '12345645', 1, NULL);


#
# TABLE STRUCTURE FOR: penerimaan
#

DROP TABLE IF EXISTS `penerimaan`;

CREATE TABLE `penerimaan` (
  `id` int NOT NULL AUTO_INCREMENT,
  `faktur` varchar(50) DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `id_supplier` int DEFAULT NULL,
  `user_input` int DEFAULT NULL,
  `id_gudang` int DEFAULT NULL,
  `tgl_input` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `id_gudang` (`id_gudang`),
  KEY `id_supplier` (`id_supplier`),
  CONSTRAINT `penerimaan_ibfk_1` FOREIGN KEY (`id_gudang`) REFERENCES `gudang` (`id`),
  CONSTRAINT `penerimaan_ibfk_2` FOREIGN KEY (`id_supplier`) REFERENCES `supplier` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `penerimaan` (`id`, `faktur`, `tanggal`, `id_supplier`, `user_input`, `id_gudang`, `tgl_input`) VALUES (3, 'PNR-00001-1/17-12-2022', '2022-12-17', 1, 1, 1, '2022-12-17 09:19:43');
INSERT INTO `penerimaan` (`id`, `faktur`, `tanggal`, `id_supplier`, `user_input`, `id_gudang`, `tgl_input`) VALUES (4, 'PNR-00002-1/17-12-2022', '2022-12-17', 2, 1, 1, '2022-12-17 22:44:41');


#
# TABLE STRUCTURE FOR: penerimaan_detail
#

DROP TABLE IF EXISTS `penerimaan_detail`;

CREATE TABLE `penerimaan_detail` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_penerimaan` int DEFAULT NULL,
  `id_barang` int DEFAULT NULL,
  `harga` double DEFAULT NULL,
  `jumlah` double DEFAULT NULL,
  `kemasan` int DEFAULT NULL,
  `nobatch` varchar(50) DEFAULT NULL,
  `ed` date DEFAULT NULL,
  `id_user` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_penerimaan_fk` (`id_penerimaan`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `penerimaan_detail` (`id`, `id_penerimaan`, `id_barang`, `harga`, `jumlah`, `kemasan`, `nobatch`, `ed`, `id_user`) VALUES (4, 3, 5, '34000', '10', 1, '234234', '2023-03-31', 1);
INSERT INTO `penerimaan_detail` (`id`, `id_penerimaan`, `id_barang`, `harga`, `jumlah`, `kemasan`, `nobatch`, `ed`, `id_user`) VALUES (5, 3, 4, '200000', '10', 1, '32342342', '2023-02-28', 1);
INSERT INTO `penerimaan_detail` (`id`, `id_penerimaan`, `id_barang`, `harga`, `jumlah`, `kemasan`, `nobatch`, `ed`, `id_user`) VALUES (6, 3, 6, '23000', '43', 1, '21', '2022-12-17', 1);
INSERT INTO `penerimaan_detail` (`id`, `id_penerimaan`, `id_barang`, `harga`, `jumlah`, `kemasan`, `nobatch`, `ed`, `id_user`) VALUES (7, 4, 4, '200000', '2', 1, '23456', '2023-04-29', 1);


#
# TABLE STRUCTURE FOR: perundangan
#

DROP TABLE IF EXISTS `perundangan`;

CREATE TABLE `perundangan` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) DEFAULT NULL,
  `id_gudang` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `perundangan` (`id`, `nama`, `id_gudang`) VALUES (1, 'Bebas', NULL);
INSERT INTO `perundangan` (`id`, `nama`, `id_gudang`) VALUES (2, 'OOT', NULL);
INSERT INTO `perundangan` (`id`, `nama`, `id_gudang`) VALUES (3, 'Alkes', NULL);
INSERT INTO `perundangan` (`id`, `nama`, `id_gudang`) VALUES (4, 'Prekursor', NULL);


#
# TABLE STRUCTURE FOR: retur_keluar
#

DROP TABLE IF EXISTS `retur_keluar`;

CREATE TABLE `retur_keluar` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tanggal` date DEFAULT NULL,
  `id_pelanggan` int DEFAULT NULL,
  `user_input` int DEFAULT NULL,
  `id_gudang` int DEFAULT NULL,
  `tgl_input` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

#
# TABLE STRUCTURE FOR: retur_keluar_detail
#

DROP TABLE IF EXISTS `retur_keluar_detail`;

CREATE TABLE `retur_keluar_detail` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_retur_keluar` int DEFAULT NULL,
  `id_barang` int DEFAULT NULL,
  `id_kemasan` int DEFAULT NULL,
  `ed` date DEFAULT NULL,
  `jumlah` double DEFAULT NULL,
  `id_user` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_barang` (`id_barang`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

#
# TABLE STRUCTURE FOR: retur_penerimaan
#

DROP TABLE IF EXISTS `retur_penerimaan`;

CREATE TABLE `retur_penerimaan` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tanggal` date DEFAULT NULL,
  `id_supplier` int DEFAULT NULL,
  `user_input` int DEFAULT NULL,
  `id_gudang` int DEFAULT NULL,
  `tgl_input` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

#
# TABLE STRUCTURE FOR: retur_penerimaan_detail
#

DROP TABLE IF EXISTS `retur_penerimaan_detail`;

CREATE TABLE `retur_penerimaan_detail` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_retur_penerimaan` int DEFAULT NULL,
  `id_barang` int DEFAULT NULL,
  `id_kemasan` int DEFAULT NULL,
  `ed` date DEFAULT NULL,
  `jumlah` double DEFAULT NULL,
  `id_user` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_barang` (`id_barang`),
  CONSTRAINT `retur_penerimaan_detail_ibfk_1` FOREIGN KEY (`id_barang`) REFERENCES `barang` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

#
# TABLE STRUCTURE FOR: satuan
#

DROP TABLE IF EXISTS `satuan`;

CREATE TABLE `satuan` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) DEFAULT NULL,
  `id_gudang` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `satuan` (`id`, `nama`, `id_gudang`) VALUES (1, 'Strip', NULL);
INSERT INTO `satuan` (`id`, `nama`, `id_gudang`) VALUES (2, 'Kaplet', NULL);


#
# TABLE STRUCTURE FOR: stok_opname
#

DROP TABLE IF EXISTS `stok_opname`;

CREATE TABLE `stok_opname` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_transaksi` int DEFAULT NULL,
  `id_barang` int DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `transaksi` enum('Stok Opname','Penerimaan','Keluar','Koreksi Stok','Retur Keluar','Retur Penerimaan') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `ed` date DEFAULT NULL,
  `nobatch` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `masuk` double NOT NULL DEFAULT '0',
  `keluar` double NOT NULL DEFAULT '0',
  `keterangan` text,
  `user_input` int DEFAULT NULL,
  `id_gudang` int DEFAULT NULL,
  `tgl_input` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `id_barang_fk` (`id_barang`),
  KEY `id_gudang` (`id_gudang`),
  CONSTRAINT `id_barang_fk` FOREIGN KEY (`id_barang`) REFERENCES `barang` (`id`),
  CONSTRAINT `stok_opname_ibfk_1` FOREIGN KEY (`id_gudang`) REFERENCES `gudang` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `stok_opname` (`id`, `id_transaksi`, `id_barang`, `tanggal`, `transaksi`, `ed`, `nobatch`, `masuk`, `keluar`, `keterangan`, `user_input`, `id_gudang`, `tgl_input`) VALUES (4, 4, 5, '2022-12-17', 'Penerimaan', '2023-03-31', '234234', '10', '0', NULL, 1, 1, '2022-12-17 09:19:43');
INSERT INTO `stok_opname` (`id`, `id_transaksi`, `id_barang`, `tanggal`, `transaksi`, `ed`, `nobatch`, `masuk`, `keluar`, `keterangan`, `user_input`, `id_gudang`, `tgl_input`) VALUES (5, 5, 4, '2022-12-17', 'Penerimaan', '2023-02-28', '32342342', '10', '0', NULL, 1, 1, '2022-12-17 09:21:13');
INSERT INTO `stok_opname` (`id`, `id_transaksi`, `id_barang`, `tanggal`, `transaksi`, `ed`, `nobatch`, `masuk`, `keluar`, `keterangan`, `user_input`, `id_gudang`, `tgl_input`) VALUES (6, 6, 6, '2022-12-17', 'Penerimaan', '2022-12-31', '21', '43', '0', NULL, 1, 1, '2022-12-17 09:40:21');
INSERT INTO `stok_opname` (`id`, `id_transaksi`, `id_barang`, `tanggal`, `transaksi`, `ed`, `nobatch`, `masuk`, `keluar`, `keterangan`, `user_input`, `id_gudang`, `tgl_input`) VALUES (10, 7, 4, '2022-12-17', 'Penerimaan', '2023-04-29', '23456', '2', '0', NULL, 1, 1, '2022-12-17 22:44:41');
INSERT INTO `stok_opname` (`id`, `id_transaksi`, `id_barang`, `tanggal`, `transaksi`, `ed`, `nobatch`, `masuk`, `keluar`, `keterangan`, `user_input`, `id_gudang`, `tgl_input`) VALUES (22, 2, 4, '2022-12-18', 'Keluar', '2023-02-28', '23456', '0', '2', NULL, 1, 1, '2022-12-18 16:40:38');
INSERT INTO `stok_opname` (`id`, `id_transaksi`, `id_barang`, `tanggal`, `transaksi`, `ed`, `nobatch`, `masuk`, `keluar`, `keterangan`, `user_input`, `id_gudang`, `tgl_input`) VALUES (23, 7, 4, '2022-12-18', 'Keluar', '2023-02-28', '32342342', '0', '5', NULL, 1, 1, '2022-12-18 16:50:14');


#
# TABLE STRUCTURE FOR: supplier
#

DROP TABLE IF EXISTS `supplier`;

CREATE TABLE `supplier` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) DEFAULT NULL,
  `notelp` varchar(50) DEFAULT NULL,
  `alamat` text,
  `sipa` varchar(200) DEFAULT NULL,
  `user_input` int DEFAULT NULL,
  `id_gudang` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_gudang` (`id_gudang`),
  KEY `user_input` (`user_input`),
  CONSTRAINT `supplier_ibfk_1` FOREIGN KEY (`id_gudang`) REFERENCES `gudang` (`id`),
  CONSTRAINT `supplier_ibfk_2` FOREIGN KEY (`user_input`) REFERENCES `tbl_user` (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `supplier` (`id`, `nama`, `notelp`, `alamat`, `sipa`, `user_input`, `id_gudang`) VALUES (1, 'test sp', '08776123131', 'jalan smasjdnasd', 'sipa1233', 1, NULL);
INSERT INTO `supplier` (`id`, `nama`, `notelp`, `alamat`, `sipa`, `user_input`, `id_gudang`) VALUES (2, 'suplier 1', '1232321', 'sdasda', 'asdasda', 1, NULL);


#
# TABLE STRUCTURE FOR: tbl_akses_menu
#

DROP TABLE IF EXISTS `tbl_akses_menu`;

CREATE TABLE `tbl_akses_menu` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_level` int NOT NULL,
  `id_menu` int NOT NULL,
  `view` enum('Y','N') NOT NULL DEFAULT 'N',
  `add` enum('Y','N') NOT NULL DEFAULT 'N',
  `edit` enum('Y','N') NOT NULL DEFAULT 'N',
  `delete` enum('Y','N') NOT NULL DEFAULT 'N',
  `print` enum('Y','N') NOT NULL DEFAULT 'N',
  `upload` enum('Y','N') NOT NULL DEFAULT 'N',
  `download` enum('Y','N') NOT NULL DEFAULT 'N',
  PRIMARY KEY (`id`),
  KEY `id_menu` (`id_menu`)
) ENGINE=InnoDB AUTO_INCREMENT=420 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `tbl_akses_menu` (`id`, `id_level`, `id_menu`, `view`, `add`, `edit`, `delete`, `print`, `upload`, `download`) VALUES (1, 1, 1, 'Y', 'N', 'N', 'N', 'N', 'N', 'N');
INSERT INTO `tbl_akses_menu` (`id`, `id_level`, `id_menu`, `view`, `add`, `edit`, `delete`, `print`, `upload`, `download`) VALUES (69, 1, 57, 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'N');
INSERT INTO `tbl_akses_menu` (`id`, `id_level`, `id_menu`, `view`, `add`, `edit`, `delete`, `print`, `upload`, `download`) VALUES (94, 1, 61, 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'N');
INSERT INTO `tbl_akses_menu` (`id`, `id_level`, `id_menu`, `view`, `add`, `edit`, `delete`, `print`, `upload`, `download`) VALUES (207, 1, 93, 'Y', 'N', 'N', 'N', 'N', 'N', 'N');
INSERT INTO `tbl_akses_menu` (`id`, `id_level`, `id_menu`, `view`, `add`, `edit`, `delete`, `print`, `upload`, `download`) VALUES (410, 6, 1, 'Y', 'N', 'N', 'N', 'N', 'N', 'N');
INSERT INTO `tbl_akses_menu` (`id`, `id_level`, `id_menu`, `view`, `add`, `edit`, `delete`, `print`, `upload`, `download`) VALUES (411, 6, 57, 'N', 'N', 'N', 'N', 'N', 'N', 'N');
INSERT INTO `tbl_akses_menu` (`id`, `id_level`, `id_menu`, `view`, `add`, `edit`, `delete`, `print`, `upload`, `download`) VALUES (412, 6, 61, 'Y', 'N', 'N', 'N', 'N', 'N', 'N');
INSERT INTO `tbl_akses_menu` (`id`, `id_level`, `id_menu`, `view`, `add`, `edit`, `delete`, `print`, `upload`, `download`) VALUES (413, 6, 93, 'N', 'N', 'N', 'N', 'N', 'N', 'N');
INSERT INTO `tbl_akses_menu` (`id`, `id_level`, `id_menu`, `view`, `add`, `edit`, `delete`, `print`, `upload`, `download`) VALUES (414, 1, 111, 'Y', 'N', 'N', 'N', 'N', 'N', 'N');
INSERT INTO `tbl_akses_menu` (`id`, `id_level`, `id_menu`, `view`, `add`, `edit`, `delete`, `print`, `upload`, `download`) VALUES (415, 6, 111, 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y');
INSERT INTO `tbl_akses_menu` (`id`, `id_level`, `id_menu`, `view`, `add`, `edit`, `delete`, `print`, `upload`, `download`) VALUES (416, 1, 112, 'Y', 'N', 'N', 'N', 'N', 'N', 'N');
INSERT INTO `tbl_akses_menu` (`id`, `id_level`, `id_menu`, `view`, `add`, `edit`, `delete`, `print`, `upload`, `download`) VALUES (417, 6, 112, 'N', 'N', 'N', 'N', 'N', 'N', 'N');
INSERT INTO `tbl_akses_menu` (`id`, `id_level`, `id_menu`, `view`, `add`, `edit`, `delete`, `print`, `upload`, `download`) VALUES (418, 1, 113, 'Y', 'N', 'N', 'N', 'N', 'N', 'N');
INSERT INTO `tbl_akses_menu` (`id`, `id_level`, `id_menu`, `view`, `add`, `edit`, `delete`, `print`, `upload`, `download`) VALUES (419, 6, 113, 'N', 'N', 'N', 'N', 'N', 'N', 'N');


#
# TABLE STRUCTURE FOR: tbl_akses_submenu
#

DROP TABLE IF EXISTS `tbl_akses_submenu`;

CREATE TABLE `tbl_akses_submenu` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `id_level` int NOT NULL,
  `id_submenu` int NOT NULL,
  `view` enum('Y','N') NOT NULL DEFAULT 'N',
  `add` enum('Y','N') NOT NULL DEFAULT 'N',
  `edit` enum('Y','N') NOT NULL DEFAULT 'N',
  `delete` enum('Y','N') NOT NULL DEFAULT 'N',
  `print` enum('Y','N') NOT NULL DEFAULT 'N',
  `upload` enum('Y','N') NOT NULL DEFAULT 'N',
  `download` enum('Y','N') NOT NULL DEFAULT 'N',
  PRIMARY KEY (`id`),
  KEY `id_level` (`id_level`),
  KEY `id_submenu` (`id_submenu`)
) ENGINE=InnoDB AUTO_INCREMENT=321 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view`, `add`, `edit`, `delete`, `print`, `upload`, `download`) VALUES (2, 1, 2, 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'N');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view`, `add`, `edit`, `delete`, `print`, `upload`, `download`) VALUES (4, 1, 1, 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'N');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view`, `add`, `edit`, `delete`, `print`, `upload`, `download`) VALUES (6, 1, 7, 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'N');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view`, `add`, `edit`, `delete`, `print`, `upload`, `download`) VALUES (9, 1, 10, 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'N');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view`, `add`, `edit`, `delete`, `print`, `upload`, `download`) VALUES (209, 1, 44, 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view`, `add`, `edit`, `delete`, `print`, `upload`, `download`) VALUES (284, 6, 1, 'N', 'N', 'N', 'N', 'N', 'N', 'N');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view`, `add`, `edit`, `delete`, `print`, `upload`, `download`) VALUES (285, 6, 2, 'N', 'N', 'N', 'N', 'N', 'N', 'N');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view`, `add`, `edit`, `delete`, `print`, `upload`, `download`) VALUES (286, 6, 7, 'N', 'N', 'N', 'N', 'N', 'N', 'N');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view`, `add`, `edit`, `delete`, `print`, `upload`, `download`) VALUES (287, 6, 10, 'N', 'N', 'N', 'N', 'N', 'N', 'N');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view`, `add`, `edit`, `delete`, `print`, `upload`, `download`) VALUES (288, 6, 44, 'N', 'N', 'N', 'N', 'N', 'N', 'N');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view`, `add`, `edit`, `delete`, `print`, `upload`, `download`) VALUES (289, 1, 52, 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view`, `add`, `edit`, `delete`, `print`, `upload`, `download`) VALUES (290, 6, 52, 'N', 'N', 'N', 'N', 'N', 'N', 'N');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view`, `add`, `edit`, `delete`, `print`, `upload`, `download`) VALUES (291, 1, 53, 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view`, `add`, `edit`, `delete`, `print`, `upload`, `download`) VALUES (292, 6, 53, 'N', 'N', 'N', 'N', 'N', 'N', 'N');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view`, `add`, `edit`, `delete`, `print`, `upload`, `download`) VALUES (293, 1, 54, 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view`, `add`, `edit`, `delete`, `print`, `upload`, `download`) VALUES (294, 6, 54, 'N', 'N', 'N', 'N', 'N', 'N', 'N');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view`, `add`, `edit`, `delete`, `print`, `upload`, `download`) VALUES (295, 1, 55, 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view`, `add`, `edit`, `delete`, `print`, `upload`, `download`) VALUES (296, 6, 55, 'N', 'N', 'N', 'N', 'N', 'N', 'N');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view`, `add`, `edit`, `delete`, `print`, `upload`, `download`) VALUES (297, 1, 56, 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view`, `add`, `edit`, `delete`, `print`, `upload`, `download`) VALUES (298, 6, 56, 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view`, `add`, `edit`, `delete`, `print`, `upload`, `download`) VALUES (299, 1, 57, 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view`, `add`, `edit`, `delete`, `print`, `upload`, `download`) VALUES (300, 6, 57, 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view`, `add`, `edit`, `delete`, `print`, `upload`, `download`) VALUES (301, 1, 58, 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view`, `add`, `edit`, `delete`, `print`, `upload`, `download`) VALUES (302, 6, 58, 'N', 'N', 'N', 'N', 'N', 'N', 'N');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view`, `add`, `edit`, `delete`, `print`, `upload`, `download`) VALUES (303, 1, 59, 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view`, `add`, `edit`, `delete`, `print`, `upload`, `download`) VALUES (304, 6, 59, 'N', 'N', 'N', 'N', 'N', 'N', 'N');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view`, `add`, `edit`, `delete`, `print`, `upload`, `download`) VALUES (305, 1, 60, 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view`, `add`, `edit`, `delete`, `print`, `upload`, `download`) VALUES (306, 6, 60, 'N', 'N', 'N', 'N', 'N', 'N', 'N');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view`, `add`, `edit`, `delete`, `print`, `upload`, `download`) VALUES (307, 1, 61, 'Y', 'N', 'N', 'N', 'N', 'N', 'N');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view`, `add`, `edit`, `delete`, `print`, `upload`, `download`) VALUES (308, 6, 61, 'N', 'N', 'N', 'N', 'N', 'N', 'N');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view`, `add`, `edit`, `delete`, `print`, `upload`, `download`) VALUES (309, 1, 62, 'Y', 'N', 'N', 'N', 'N', 'N', 'N');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view`, `add`, `edit`, `delete`, `print`, `upload`, `download`) VALUES (310, 6, 62, 'N', 'N', 'N', 'N', 'N', 'N', 'N');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view`, `add`, `edit`, `delete`, `print`, `upload`, `download`) VALUES (311, 1, 63, 'Y', 'N', 'N', 'N', 'N', 'N', 'N');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view`, `add`, `edit`, `delete`, `print`, `upload`, `download`) VALUES (312, 6, 63, 'N', 'N', 'N', 'N', 'N', 'N', 'N');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view`, `add`, `edit`, `delete`, `print`, `upload`, `download`) VALUES (313, 1, 64, 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view`, `add`, `edit`, `delete`, `print`, `upload`, `download`) VALUES (314, 6, 64, 'N', 'N', 'N', 'N', 'N', 'N', 'N');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view`, `add`, `edit`, `delete`, `print`, `upload`, `download`) VALUES (315, 1, 65, 'Y', 'N', 'N', 'N', 'N', 'N', 'N');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view`, `add`, `edit`, `delete`, `print`, `upload`, `download`) VALUES (316, 6, 65, 'N', 'N', 'N', 'N', 'N', 'N', 'N');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view`, `add`, `edit`, `delete`, `print`, `upload`, `download`) VALUES (317, 1, 66, 'Y', 'N', 'N', 'N', 'N', 'N', 'N');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view`, `add`, `edit`, `delete`, `print`, `upload`, `download`) VALUES (318, 6, 66, 'N', 'N', 'N', 'N', 'N', 'N', 'N');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view`, `add`, `edit`, `delete`, `print`, `upload`, `download`) VALUES (319, 1, 67, 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view`, `add`, `edit`, `delete`, `print`, `upload`, `download`) VALUES (320, 6, 67, 'N', 'N', 'N', 'N', 'N', 'N', 'N');


#
# TABLE STRUCTURE FOR: tbl_menu
#

DROP TABLE IF EXISTS `tbl_menu`;

CREATE TABLE `tbl_menu` (
  `id_menu` int NOT NULL AUTO_INCREMENT,
  `nama_menu` varchar(50) DEFAULT NULL,
  `link` varchar(100) DEFAULT NULL,
  `icon` varchar(50) DEFAULT NULL,
  `urutan` bigint DEFAULT NULL,
  `is_active` enum('Y','N') DEFAULT 'Y',
  `parent` enum('Y') DEFAULT 'Y',
  PRIMARY KEY (`id_menu`)
) ENGINE=InnoDB AUTO_INCREMENT=114 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `tbl_menu` (`id_menu`, `nama_menu`, `link`, `icon`, `urutan`, `is_active`, `parent`) VALUES (1, 'Dashboard', 'dashboard', 'fas fa-tachometer-alt', '1', 'Y', 'Y');
INSERT INTO `tbl_menu` (`id_menu`, `nama_menu`, `link`, `icon`, `urutan`, `is_active`, `parent`) VALUES (57, 'Konfigurasi', '#', 'fas fa-users-cog', '15', 'Y', 'Y');
INSERT INTO `tbl_menu` (`id_menu`, `nama_menu`, `link`, `icon`, `urutan`, `is_active`, `parent`) VALUES (61, 'Ganti Password', 'ganti_password', 'fas fa-key', '9', 'Y', 'Y');
INSERT INTO `tbl_menu` (`id_menu`, `nama_menu`, `link`, `icon`, `urutan`, `is_active`, `parent`) VALUES (93, 'Data Master', '#', 'fas fa-database', '5', 'Y', 'Y');
INSERT INTO `tbl_menu` (`id_menu`, `nama_menu`, `link`, `icon`, `urutan`, `is_active`, `parent`) VALUES (111, 'Transaksi', '#', 'fas fa-shopping-cart', '2', 'Y', 'Y');
INSERT INTO `tbl_menu` (`id_menu`, `nama_menu`, `link`, `icon`, `urutan`, `is_active`, `parent`) VALUES (112, 'Laporan', '#', 'fas fa-book', '6', 'Y', 'Y');
INSERT INTO `tbl_menu` (`id_menu`, `nama_menu`, `link`, `icon`, `urutan`, `is_active`, `parent`) VALUES (113, 'Grafik', 'grafik', 'nav-icon fas fa-chart-pie', '5', 'Y', 'Y');


#
# TABLE STRUCTURE FOR: tbl_submenu
#

DROP TABLE IF EXISTS `tbl_submenu`;

CREATE TABLE `tbl_submenu` (
  `id_submenu` int NOT NULL AUTO_INCREMENT,
  `nama_submenu` varchar(50) DEFAULT NULL,
  `link` varchar(100) DEFAULT NULL,
  `icon` varchar(50) DEFAULT NULL,
  `id_menu` int DEFAULT NULL,
  `is_active` enum('Y','N') DEFAULT 'Y',
  PRIMARY KEY (`id_submenu`)
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `tbl_submenu` (`id_submenu`, `nama_submenu`, `link`, `icon`, `id_menu`, `is_active`) VALUES (1, 'Menu', 'menu', 'far fa-circle', 57, 'Y');
INSERT INTO `tbl_submenu` (`id_submenu`, `nama_submenu`, `link`, `icon`, `id_menu`, `is_active`) VALUES (2, 'Sub Menu', 'submenu', 'far fa-circle', 57, 'Y');
INSERT INTO `tbl_submenu` (`id_submenu`, `nama_submenu`, `link`, `icon`, `id_menu`, `is_active`) VALUES (7, 'Aplikasi', 'aplikasi', 'far fa-circle', 57, 'Y');
INSERT INTO `tbl_submenu` (`id_submenu`, `nama_submenu`, `link`, `icon`, `id_menu`, `is_active`) VALUES (10, 'User Level', 'userlevel', 'far fa-circle', 57, 'Y');
INSERT INTO `tbl_submenu` (`id_submenu`, `nama_submenu`, `link`, `icon`, `id_menu`, `is_active`) VALUES (44, 'Data Pengguna', 'user', 'far fa-circle', 57, 'Y');
INSERT INTO `tbl_submenu` (`id_submenu`, `nama_submenu`, `link`, `icon`, `id_menu`, `is_active`) VALUES (52, 'Barang', 'barang', 'far fa-circle', 93, 'Y');
INSERT INTO `tbl_submenu` (`id_submenu`, `nama_submenu`, `link`, `icon`, `id_menu`, `is_active`) VALUES (53, 'Supplier', 'supplier', 'far fa-circle', 93, 'Y');
INSERT INTO `tbl_submenu` (`id_submenu`, `nama_submenu`, `link`, `icon`, `id_menu`, `is_active`) VALUES (54, 'Pelanggan', 'pelanggan', 'far fa-circle', 93, 'Y');
INSERT INTO `tbl_submenu` (`id_submenu`, `nama_submenu`, `link`, `icon`, `id_menu`, `is_active`) VALUES (55, 'Satuan', 'satuan', 'far fa-circle', 93, 'Y');
INSERT INTO `tbl_submenu` (`id_submenu`, `nama_submenu`, `link`, `icon`, `id_menu`, `is_active`) VALUES (56, 'Penerimaan', 'penerimaan', 'far fa-circle', 111, 'Y');
INSERT INTO `tbl_submenu` (`id_submenu`, `nama_submenu`, `link`, `icon`, `id_menu`, `is_active`) VALUES (57, 'Barang Keluar', 'keluar', 'far fa-circle', 111, 'Y');
INSERT INTO `tbl_submenu` (`id_submenu`, `nama_submenu`, `link`, `icon`, `id_menu`, `is_active`) VALUES (58, 'Gudang', 'gudang', 'far fa-circle', 57, 'Y');
INSERT INTO `tbl_submenu` (`id_submenu`, `nama_submenu`, `link`, `icon`, `id_menu`, `is_active`) VALUES (59, 'Retur Penerimaan', 'retur_penerimaan', 'far fa-circle', 111, 'Y');
INSERT INTO `tbl_submenu` (`id_submenu`, `nama_submenu`, `link`, `icon`, `id_menu`, `is_active`) VALUES (60, 'Stok Opname', 'stok', 'far fa-circle', 111, 'Y');
INSERT INTO `tbl_submenu` (`id_submenu`, `nama_submenu`, `link`, `icon`, `id_menu`, `is_active`) VALUES (61, 'Arus Stok', 'arus_stok', 'far fa-circle', 112, 'Y');
INSERT INTO `tbl_submenu` (`id_submenu`, `nama_submenu`, `link`, `icon`, `id_menu`, `is_active`) VALUES (62, 'Barang Keluar', 'lap_kb', 'far fa-circle', 112, 'Y');
INSERT INTO `tbl_submenu` (`id_submenu`, `nama_submenu`, `link`, `icon`, `id_menu`, `is_active`) VALUES (63, 'Penerimaan', 'lap_tb', 'far fa-circle', 112, 'Y');
INSERT INTO `tbl_submenu` (`id_submenu`, `nama_submenu`, `link`, `icon`, `id_menu`, `is_active`) VALUES (64, 'Perundangan', 'perundangan', 'far fa-circle', 93, 'Y');
INSERT INTO `tbl_submenu` (`id_submenu`, `nama_submenu`, `link`, `icon`, `id_menu`, `is_active`) VALUES (65, 'Sisa Stok', 'sisa_stok', 'far fa-circle', 112, 'Y');
INSERT INTO `tbl_submenu` (`id_submenu`, `nama_submenu`, `link`, `icon`, `id_menu`, `is_active`) VALUES (66, 'Expired Obat', 'expired', 'far fa-circle', 112, 'Y');
INSERT INTO `tbl_submenu` (`id_submenu`, `nama_submenu`, `link`, `icon`, `id_menu`, `is_active`) VALUES (67, 'Retur Keluar', 'retur_keluar', 'far fa-circle', 111, 'Y');


#
# TABLE STRUCTURE FOR: tbl_user
#

DROP TABLE IF EXISTS `tbl_user`;

CREATE TABLE `tbl_user` (
  `id_user` int NOT NULL AUTO_INCREMENT,
  `username` varchar(20) DEFAULT NULL,
  `full_name` varchar(50) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `id_level` int DEFAULT NULL,
  `image` varchar(500) DEFAULT NULL,
  `nohp` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `is_active` enum('Y','N') DEFAULT 'Y',
  `id_gudang` int DEFAULT NULL,
  PRIMARY KEY (`id_user`),
  KEY `id_level` (`id_level`),
  KEY `id_gudang_fk` (`id_gudang`),
  CONSTRAINT `id_gudang_fk` FOREIGN KEY (`id_gudang`) REFERENCES `gudang` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `tbl_user` (`id_user`, `username`, `full_name`, `password`, `id_level`, `image`, `nohp`, `email`, `is_active`, `id_gudang`) VALUES (1, 'admin', 'Administrator', '$2y$05$Bl1UXpDrO8843SqKlnGkq.AjnPhDIGAbfKAoVUkqpUAp4um3LtrbW', 1, 'admin.jpg', '08129837323', 'admin11@gmail.com', 'Y', 1);
INSERT INTO `tbl_user` (`id_user`, `username`, `full_name`, `password`, `id_level`, `image`, `nohp`, `email`, `is_active`, `id_gudang`) VALUES (30, 'user', 'User', '$2y$05$KZmtybRugl1zs3.3EPx/YeqSLd8qVx1OiuWmM6Z9h7OMuG.Id5L0W', 6, 'user.png', NULL, NULL, 'Y', 2);


#
# TABLE STRUCTURE FOR: tbl_userlevel
#

DROP TABLE IF EXISTS `tbl_userlevel`;

CREATE TABLE `tbl_userlevel` (
  `id_level` int NOT NULL AUTO_INCREMENT,
  `nama_level` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_level`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `tbl_userlevel` (`id_level`, `nama_level`) VALUES (1, 'admin');
INSERT INTO `tbl_userlevel` (`id_level`, `nama_level`) VALUES (6, 'user');


#
# TABLE STRUCTURE FOR: template_color
#

DROP TABLE IF EXISTS `template_color`;

CREATE TABLE `template_color` (
  `id` int NOT NULL AUTO_INCREMENT,
  `header` varchar(50) DEFAULT NULL,
  `dark_sidebar` varchar(50) DEFAULT NULL,
  `light_sidebar` varchar(50) DEFAULT NULL,
  `logo` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `template_color` (`id`, `header`, `dark_sidebar`, `light_sidebar`, `logo`) VALUES (1, NULL, NULL, NULL, NULL);


