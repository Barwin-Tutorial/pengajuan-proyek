
<!-- Main content -->
<section class="content">
  
        <div class="text-center">
        	<p>Selamat Datang </p><h4> <?php echo $this->session->userdata('full_name'); ?></h4>

        </div>
    
</section>
